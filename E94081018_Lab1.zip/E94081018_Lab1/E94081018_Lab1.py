print("lb    oz    kg")
lb = 1
for i in range(10):
    oz = lb * 16  # transform lb to oz
    kg = float(lb) * 0.45359 # transform lb to kg
    print("{0:2d}".format(lb), ",", "{0:3d}".format(oz), ",", "{:.5f}".format(kg))
    lb = lb + 1

