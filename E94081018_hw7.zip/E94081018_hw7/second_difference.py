import numpy as np
import matplotlib.pyplot as plt
plt.style.use("seaborn-poster")


# function of second order approximation
def sec_order_diff(y):
    y_temp = np.zeros((len(y)))
    for j in range(len(y)-2):
        y_temp[j+1] = (y[j+2] - 2*y[j+1] + y[j])
    y_temp = y_temp/(h*h)
    return y_temp


# function of finite difference approximation(forward)
def forward_diff(y):
    y_temp = np.zeros((len(y)))
    for j in range(len(y)-1):
        y_temp[j] = (y[j+1] - y[j])
    y_temp = y_temp/h
    return y_temp


# function of finite difference approximation(backward)
def backward_diff(y):
    y_temp = np.zeros((len(y)))
    for j in range(len(y)-2):
        y_temp[j] = (y[j+1] - y[j])
    y_temp = y_temp/h
    return y_temp


# setup
h = 0.1
x = np.arange(-2, 4, h)
y = (1/4)*(x**4) + (1/3)*(x**3) + 5*x


# get forward difference
forward_diff = forward_diff(y)
# substitute into backward difference
backward_diff = backward_diff(forward_diff)

# get second order difference
sec_order_diff = sec_order_diff(y)

# trim array
x_diff = x[1:-1]
backward_diff = backward_diff[0:-2]
sec_order_diff = sec_order_diff[1:-1]

# get exact solution
exact_solution = 3*(x_diff**2) + 2*x_diff

# plot figure
plt.figure(figsize = (12, 8))
plt.plot(x_diff, exact_solution, label = "Exact solution", linewidth=12, color="darkblue")
plt.plot(x_diff, backward_diff, label = "Finite difference approximation", linewidth=5, color="orange", linestyle="--")
plt.plot(x_diff, sec_order_diff, label = "Second-order approximation", markersize=13, color='lime', marker="*", linestyle=" ")
plt.legend()
plt.show()

# get max error
max_error_finite = max(abs(exact_solution - backward_diff))
max_error = max(abs(exact_solution - sec_order_diff))
print("error of finite difference:", max_error_finite)
print("error of second-order:", max_error)



